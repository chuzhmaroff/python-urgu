Сайт поднят и действует по адресу https://importthis.pythonanywhere.com/
Сайт со статистикой сайта по адресу https://serverimportthis.pythonanywhere.com/stat